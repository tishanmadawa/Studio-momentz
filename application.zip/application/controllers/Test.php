<?php
	class Test extends CI_Controller{

		public function hello(){

			echo "Hi i am default controller";
		}

		
	}




?>