<?php
	class Booking extends CI_Controller{

		public function __construct(){
			parent::__construct();
			$this->load->model('BookingModel');
			$this->load->helper('url');

		}

		public function view(){
			
			
		$this->load->view('booking');
	}	

	public function add(){
		 
		 $data=array(

		 
		 'phone' =>$this->input->post('phone'),
		 		 'contact' =>$this->input->post('contact'),

		 'eventNameOrClientName' =>$this->input->post('eventNameOrClientName'),

		 'eventDate' =>$this->input->post('eventDate'),

		 'eventStartTime' =>$this->input->post('eventStartTime'),

		 'eventEndTime' =>$this->input->post('eventEndTime'),


		 'eventLocation' =>$this->input->post('eventLocation'),

		 'package' =>$this->input->post('package'),

		 'image' =>$this->input->post('image'),
		 'timeline' =>$this->input->post('timeline'),
		 'social' =>$this->input->post('social'));

		 $this->BookingModel->form_insert($data);

		 $this->load->view("booking");


		 
		}

		public function eventView(){
			
			$data['result']=$this->BookingModel->view_event();
			$this->load->view('bookingDetails',$data);
			
		}
		public function search(){
			$date=$this->input->post('date');
			$data['result']=$this->BookingModel->searchData($date);
			$this->load->view('bookingDetails',$data);
		}
		public function edit(){
			$last = $this->uri->total_segments();
			$id=$this->uri->segment($last);
			$data['result']=$this->BookingModel->editData($id);
			$this->load->view('edit',$data);
		}

		public function accept(){
			$last = $this->uri->total_segments();
			$id=$this->uri->segment($last);

			$data['result']=$this->BookingModel->accept($id);
			
			redirect(base_url() . 'index.php/Booking/eventView');

		}

		public function reject(){
			$last = $this->uri->total_segments();
			$id=$this->uri->segment($last);
			$data['result']=$this->BookingModel->reject($id);
			redirect(base_url() . 'index.php/Booking/eventView');
		}
		
		
	}



?>