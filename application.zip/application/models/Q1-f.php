<?php
	class Test2 extends CI_Model{
		public function q1f1(){
			return array("fullname"=>'tishan madawa',"address"=>"ucsc");
		}
	}



?>