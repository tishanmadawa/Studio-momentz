
<!DOCTYPE html>
<html>
<head>
<title>Booking</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/bootstrap.css">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type='text/javascript' src="<?php echo base_url(); ?>js/jquery.min.js""></script>


<!-- Custom Theme files -->
<!--theme-style-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">

<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Wedding Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- start menu -->
<script type='text/javascript' src="<?php echo base_url(); ?>js/simpleCart.min.js""></script>

<!-- start menu -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/memenu.css">

<script type='text/javascript' src="<?php echo base_url(); ?>js/memenu.js""></script>

<script>$(document).ready(function(){$(".memenu").memenu();});</script>	
<!-- /start menu -->
</head>
<body style="background-color: black;"> 
<!--header-->	
<div class="top_bg" style="background-color: #5050ff; color:black;">
	<div class="container">
		<div class="header_top-sec" >
			<div class="top_right">
				<ul>
					<li><a href="contact.html">Contact</a></li>|
					<li><a href="login.html">Track Order</a></li>
				</ul>
			</div>
			<div class="top_left">
				<ul>
					<li class="top_link">Email:<a href="mailto:info@example.com">mail@example.com</a></li>|
					<li class="top_link"><a href="login.html">My Account</a></li>				
				</ul>
			</div>
				<div class="clearfix"> </div>
		</div>
	</div>
</div>
<div class="header-top">
	 <div class="header-bottom">
		 <div class="container" >			
				<div class="logo">
					<a href="index.php"><img src="<?php echo base_url(); ?>images/wed.png"></a>
				</div>
			 <!---->
		 
			 <div class="top-nav" style="float:right;margin-top: -100px;">
				<ul class="memenu skyblue"><li class="active"><a href="<?php echo base_url(); ?>index.php">Home</a></li>
					<li class="grid"><a href="gallery.php">Album</a>
					</li>
					<li><a href="#">Booking</a>
						<div class="mepanel"  style="width:300px;margin-left: 100px;">
							<div class="row">
								<div class="col5 me-one">
									<ul>
										<li><a href="booking.php" >Add Booking</a></li>
										<li><a href="boOkingDetails.php">Booking Details</a></li>
										
									</ul>
								</div>
							</div>
						</div>
					</li>
					<li class="grid"><a href="contact.php">Contact</a></li>
										<li class="grid"><a href="account.php">Sign Up</a></li>
					
				</ul>
				</ul>
				<div class="clearfix"> </div>
			 </div>
			 <div class="clearfix"> </div>
			 
			 </div>
			<div class="clearfix"> </div>
	  </div>
</div>
<!---->
<!--pages-starts-->
	<div class="pages">
		<div style="font-family:arial;   border-radius: 5px; margin-left:5%; margin-top:10px; height:60px; width:90%; align:center; padding:10px; " >
	<h1 align="center" style="margin-top:-3px; color:lightblue;">BOOKING EVENT</h1>
	</div>
	<div claa="form-inline" style="font-family:arial; color:black ; border: 1px solid DarkGray; border-radius: 10px;  margin-left:5%; margin-top:10px; width:90%; padding:10px; background-color:lightgray;" >
	</br></br>
	<?php  echo form_open('Booking/add')?>
	<table style="padding-top:10px; padding-left: 15%; width: 80%;">
	<style type="text/css">
		td{
			height: 50px;
			width: 35%;
		}


	</style>
	<div class="form-group">
	<tr>
		<td width="50%">Phone<td>
	</tr>
	<tr>
		<td width="50%"><input class="form-control" type="text" name="phone" /><td>
	</tr>
	</div>
	</table >
		<div class="form-group">

	<h3>Which method do you prefer to be contacted by?</h3>
	<input class="radio" type="radio" name="contact" value="phone"/>phone</br>
	<input class="radio" type="radio" name="contact"   value="email"/>email
	</br>
	</div>

	<h2>Event Info for Your Booking</h2>
	<hr>
	<table style="padding-top:10px; padding-right:10px; padding-left: 10px; width: 90%;">
		<div class="form-group">

	<tr>
		<td width="40%">Event Name</br> (optional)<td>
		<td width="50%"><td>
	</tr>
	<tr>
		<td width="50%"><input class="form-control" type="text" name="eventNameOrClientName" /><td>
	
	</tr>
	</div>
		<div class="form-group">

	<tr>
		<td width="50%">Event Date<td>
		
	</tr>
	<tr>
		<td width="50%"><input class="form-control" type="date" name="eventDate" /><td>
		
	</tr>
	</div>
		<div class="form-group">

	<tr>
		<td width="50%">Event Start Time<td>
		<td width="50%">Event End Time<td>
	</tr>
	<tr>
		<td width="50%"><input class="form-control" type="time" name="eventStartTime" /><td>
		<td width="50%"><input class="form-control" type="time" name="eventEndTime" /><td>
	</tr>
	</div>
		<div class="form-group">

	<tr>
		<td width="50%">Event Location</br>(optional)<td>
		
	</tr>
	<tr>
		<td width="50%"><input class="form-control" type="text" name="eventLocation" /><td>
		
	</tr>
	</div>
	</table>
		<div class="form-group">

	<h3>Event Package</h3>

	<input type="radio" name="package" value="large"/>Large Corporate Event (2 Roaming Photographers for up to 6 Hours)</br>
	<input type="radio" name="package" value="standard"/>Standard Corporate Event (1 Roaming Photographer for up to 4 Hours)</br>
	<input type="radio" name="package" value="small"/>Small Corporate or Private Event (1 Roaming Photographer for up to 2 Hours)</br>
	<input type="radio" name="package" value="custom"/>Custom Event</br></br>
	</div>
	
	<h2>Delivery Preferences</h2>
	<hr>
		<div class="form-group">

	<h3>Online Gallery of Event Images</h3>

	<input type="radio" name="image" value="public"/>Yes please! Make it public.</br>
	<input type="radio" name="image" value="passwordProtected"/>Yes please! Make it password-protected.</br>
	<input type="radio" name="image" value="download"/>Send photos via digital download.</br>
	<input type="radio" name="image" value="No"/>No thank you.</br></br>
	</div>
		<div class="form-group">

	
	<h3>Delivery timeline</h3>

	<input type="radio" name="timeline" value="standard"/>Standard (7 days)</br>
	<input type="radio" name="timeline" value="rush"/>Rush (48 hours)</br>
	<input type="radio" name="timeline" value="onSite"/>On-site editor for the day</br>
	</div>
</br>
	<div class="form-group">

	<h3>Social Media Files (up to 10) within 6 hours</h3>

	
	<input type="radio" name="social" value="yes"/>Yes, please!</br></br>
		<input type="radio" name="social" value="No"/>No</br></br>

	</br>
	</div>
	
	
<input class="btn btn-default btn-lg" type="submit" name="submit" value="submit"  style="margin-left: 80%;background-color:#5050ff;color:white; " />
</br></br>
	</br>
<?php echo form_close() ?>
</div>
</div>

<!---->
 <div class="copywrite">
	 <div class="container">
			 <p>Copyright © 2015 Wedding Store. All Rights Reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
		 </div>
</div>		 
</body>
</html>