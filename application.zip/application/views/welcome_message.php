<!DOCTYPE html>
<html>
<head>
<title>Studio Momentz</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/flexslider.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/form.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.flexisel.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/memenu.js"></script>


<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Wedding Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<script src="js/simpleCart.min.js"> </script>
<!-- start menu -->
<link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/memenu.js"></script>
<script>$(document).ready(function(){$(".memenu").memenu();});</script>	
<!-- /start menu -->
</head>
<body style="background-color: black;color:white;"> 
	
<div class="top_bg" style="background-color: #5050ff;">
		
	<div class="container">
		<div class="header_top-sec">
		<div style="margin-top: -2px;position: absolute;">
				<h2 style="font-family:vivaldi;font-size:75px;color:white;"><strong>Studio Momentz</strong></h2>
		</div>
			<div class="header-right" >
			  <h6>Follows Us:</h6>
				<ul class="f-icons">
					<li><a href="#" class="facebook"> </a></li>
					<li><a href="#" class="p"> </a></li>
					<li><a href="#" class="twitter"> </a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"> </div>
			<div class="top_left">
				<ul>
					<li class="top_link"><a href="login.html">My Account</a></li>					
				</ul>
			</div>
				<div class="clearfix"> </div>
		</div>
	</div>
</div>
<div class="header-top">
	 <div class="header-bottom">
		 <div class="container">
		 <div class="logo">
					<a href="index.php"><img src="images/wed.png""></a>
				</div>			
				
			 <!---->
		 
			 <div class="top-nav" style="margin-top: -100px;float:right;">
				<ul class="memenu skyblue"><li class="active"><a href="index.html">Home</a></li>
				<li><a href="#">Booking</a>
						<div class="mepanel">
							<div class="row">
								<div class="col1 me-one">
									<ul>
										<li><a href="index.php/booking/view" >Add Booking</a></li>
										<li><a href="index.php/booking/eventView">Booking Details</a></li>
										
									</ul>
								</div>
							</div>
						</div>
					</li>

					
					<li class="grid"><a href="gallery.php">Gallery</a>
					</li>
					<li class="grid"><a href="contact.html">Contact</a></li>
					<li class="grid"><a href="index.php/signup">Sign Up</a></li>
				</ul>
				</ul>
				<div class="clearfix"> </div>
			 </div>
			 <div class="clearfix"> </div>
			 
			 </div>
			<div class="clearfix"> </div>
	  </div>
</div>
<!---->

 
 <script defer src="js/jquery.flexslider.js"></script>



<!---->

<!---->
<br><br><br><br>
<div class="bride-grids">
	 <div class="container">
		 <div class="col-md-4 bride-grid">
			 <div class="content-grid l-grids">
				 <figure class="effect-bubba">
						<img src="images/b1.jpg" alt=""/>
						<figcaption>
							<h4>Nullam molestie </h4>
							<p>In sit amet sapien eros Integer in tincidunt labore et dolore magna aliqua</p>																
						</figcaption>			
				 </figure>
				 <div class="clearfix"></div>
				 <h3>Wedding Dresses</h3>
			 </div>
			 <div class="content-grid l-grids">
				 <figure class="effect-bubba">
						<img src="images/b2.jpg" alt=""/>
						<figcaption>
							<h4>Nullam molestie </h4>
							<p>In sit amet sapien eros Integer in tincidunt labore et dolore magna aliqua</p>																
						</figcaption>			
				 </figure>	
				 <div class="clearfix"></div>
				 <h3>BridalParty & Dresses</h3>
			 </div>
		 </div>
		 <div class="col-md-4 bride-grid">
				<div class="content-grid l-grids">
						<img src="images/b3.jpg" alt=""/>
						
				 <h3>Bridesmaid Dresses</h3>
			 </div>
		 </div>
		 <div class="col-md-4 bride-grid">
			 <div class="content-grid l-grids">
				 <figure class="effect-bubba">
						<img src="images/b4.jpg" alt=""/>
						<figcaption>
							<h4>Nullam molestie </h4>
							<p>In sit amet sapien eros Integer in tincidunt labore et dolore magna aliqua</p>																
						</figcaption>			
				 </figure>	
				 <div class="clearfix"></div>
				 <h3>Wedding</h3>
			 </div>
			 <div class="content-grid l-grids">
				 <figure class="effect-bubba">
						<img src="images/b5.jpg" alt=""/>
						<figcaption>
							<h4>Nullam molestie </h4>
							<p>In sit amet sapien eros Integer in tincidunt labore et dolore magna aliqua</p>																
						</figcaption>			
				 </figure>
					<div class="clearfix"></div>
				 <h3>Most Beautiful</h3>
			 </div>

		 </div>
		 <div class="clearfix"></div>
	 </div>
</div>
<!---->

<!---->

<!---->

<!---->
<div class="footer">
	 <div class="container">
		 <div class="ftr-grids">
			 <div class="col-md-3 ftr-grid">
				 <h4>About Us</h4>
				 <ul class="bottom">
				 	<li>Weddingstory.lk is srilankan web-portal which you may meet weddiing professionals and provide useful wedding-related information to help you in planing your big day.</li>
				 </ul>
			 </div>
			 <div class="col-md-3 ftr-grid">
				 <h4>Customer service</h4>
				 <ul>
					 <li><a href="#">FAQ</a></li>
					 <li><a href="#">Shipping</a></li>
					 <li><a href="#">Cancellation</a></li>
					 <li><a href="#">Returns</a></li>
					 <li><a href="#">Bulk Orders</a></li>
					 <li><a href="#">Buying Guides</a></li>					 
				 </ul>
			 </div>
			 <div class="col-md-3 ftr-grid">
				 <h4>Your account</h4>
				 <ul>
					 <li><a href="account.html">Your Account</a></li>
					 <li><a href="#">Personal Information</a></li>
					 <li><a href="#">Addresses</a></li>
					 <li><a href="#">Discount</a></li>
					 <li><a href="#">Track your order</a></li>					 					 
				 </ul>
			 </div>
			 <div class="col-md-3 ftr-grid">
				 <h4>Contact Us</h4>
				 <p>Tel:076 - 7188550</p>
				 <p>Email:studiomomentzz@gmail.com</p>
			 </div>
			 <div class="clearfix"></div>
		 </div>		
	 </div>
</div>
<!---->
 <div class="copywrite">
	 <div class="container">
			 <p>Copyright © 2016 Studio Momentzz. All Rights Reserved</p>
		 </div>
</div>		 
</body>
</html>
