<?php
	echo "Hi i am the simple view<br> ";
	echo "Hi i am the view and i got the parameter:";
	echo $q1;



?>